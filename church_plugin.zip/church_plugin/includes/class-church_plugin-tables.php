<?php

/**
 * Fired during plugin table
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/includes
 */

/**
 * Fired during plugin table.
 *
 * This class defines all code necessary to run during the plugin's table.
 *
 * @since      1.0.0
 * @package    church_plugin
 * @subpackage church_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_tables {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	 
	public function churchplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."church_plugin_table";
	}

}
