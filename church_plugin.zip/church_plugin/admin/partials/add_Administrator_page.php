<div class="container">
	<div class="row"> 
	    <div class="panel panel-primary">
		  <div class="panel-heading">Panel Heading</div>
		  <div class="panel-body">
			<table id="example" class="display" style="width:100%">
				<thead>
					<tr>
					    <th>Sl No</th>
						<th>Username</th>
						<th>E-mail</th>
						<th>Name</th>
						<th>Role</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody id="table_reload_first">
				  <?php 
				  	ob_start();
					include_once churchPLUGIN_URL."/admin/partials/tmfl/administor_temp_data.php";
					$template = ob_get_contents();
					ob_end_clean();
				  	echo $template;
				  ?>
				</tbody>
				<tfoot>
					<tr>
						<th>Sl No</th>
						<th>Username</th>
						<th>E-mail</th>
						<th>Name</th>
						<th>Role</th>
						<th>Action</th>
					</tr>
				</tfoot>
			</table>
		  </div>
		</div>
	</div>
</div>