<?php wp_enqueue_media(); ?>

<div class="container">
	<div class="row"> 
	    <div class="panel panel-primary">
		  <div class="panel-heading">Panel Heading</div>
		  <div class="panel-body">
		  	 <?php 
			  	ob_start();
				include_once churchPLUGIN_URL."/admin/partials/tmfl/add_temp_data.php";
				$template = ob_get_contents();
				ob_end_clean();
			  	echo $template;
			  ?>
		  </div>
		</div>
	</div>
</div>

