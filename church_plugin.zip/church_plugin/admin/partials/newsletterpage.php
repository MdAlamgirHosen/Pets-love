<?php wp_enqueue_media(); ?>

<div class="container">
	<div class="row"> 
	    <div class="panel panel-primary">
		  <div class="panel-heading">Panel Heading</div>
		  <div class="panel-body">
			<table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer" cellspacing="0" width="100%" role="grid" aria-describedby="datatable-responsive_info" style="width: 100%;">
		  <thead>
			<tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="datatable-responsive" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Sno: activate to sort column descending" style="width: 59px;">Sno</th><th class="sorting" tabindex="0" aria-controls="datatable-responsive" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending" style="width: 254px;">Email</th><th class="sorting" tabindex="0" aria-controls="datatable-responsive" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 283px;">Status</th><th class="sorting" tabindex="0" aria-controls="datatable-responsive" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 262px;">Action</th></tr>
		  </thead>
		  <tbody>
		  <tr role="row" class="odd">
			 <td class="sorting_1">1</td>
			 <td>mahamudulbbapi@gmail.com</td>
			 <td>
			 <a href="#" class="btn btn-danger btndisable">Deactive</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			 <td>
			 <a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
		    </td>
			</tr><tr role="row" class="even">
			 <td class="sorting_1">2</td>
			 <td>user@gmail.com</td>
			 <td><a href="#" class="btn btn-danger btndisable">Deactive</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			 <td>
			 <a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			</tr><tr role="row" class="odd">
			 <td class="sorting_1">3</td>
			 <td>weeww@dfsa.com</td>
			  <td>
			  <a href="#" class="btn btn-danger btndisable">Deactive</a>  <span class="disabletxt">( Demo disabled )</span>
			</td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
			</td>
			</tr><tr role="row" class="even">
			<td class="sorting_1">4</td>
			<td>fdsafds@dfsa.com</td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Deactive</a>  <span class="disabletxt">( Demo disabled )</span>
			</td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			</tr><tr role="row" class="odd">
			 <td class="sorting_1">5</td>
			<td>test@dsdd.com</td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Deactive</a>  <span class="disabletxt">( Demo disabled )</span>
			</td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
			</td>
			</tr><tr role="row" class="even">
			 <td class="sorting_1">6</td>
			 <td>new@new.com</td>
			<td><a href="#" class="btn btn-success btndisable">Active</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			<td>
			<a href="#" class="btn btn-danger btndisable">Delete</a>  <span class="disabletxt">( Demo disabled )</span>
			 </td>
			</tr></tbody>
		</table>
		  </div>
		</div>
	</div>
</div>