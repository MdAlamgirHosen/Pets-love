<?php wp_enqueue_media(); ?>
<div class="panel-body">
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">General Settings</a></li>
    <li><a data-toggle="tab" href="#menu1">Sermons Settings</a></li>
    <li><a data-toggle="tab" href="#menu2">Pages Settings</a></li>
    <li><a data-toggle="tab" href="#menu3">Media & Backgrounds</a></li>
    
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
    	<div class="wrap">
			<h1> Church Plugin Settings Options</h1>
			<?php settings_errors(); ?>
			<form method="post" action="options.php">
			    <?php settings_fields( 'genarel_options_group' ); ?>
			    <?php do_settings_sections( 'Settings' ); ?>
			         <table class="form-table">
			        	<h4>Gallery Options Settings: </h4>
				        <tr valign="top">
				        <th scope="row"><label for="gtitle_fontsize">Gallery Title Font-size</label> </th>
				        <td><input type="text" id="gtitle_fontsize" name="gtitle_fontsize" value="<?php echo esc_attr( get_option('gtitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="gtitle_color">Gallery Title Color</label> </th>
				        <td><input type="text" id="gtitle_color" name="gtitle_color" value="<?php echo esc_attr( get_option('gtitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="gtext_fontsize">Gallery Text Font-size</label> </th>
				        <td><input type="text" id="gtext_fontsize" name="gtext_fontsize" value="<?php echo esc_attr( get_option('gtext_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="gtext_color">Gallery Text Color</label> </th>
				        <td><input type="text" id="gtext_color" name="gtext_color" value="<?php echo esc_attr( get_option('gtext_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="giconchange">Gallery Icon Url</label> </th>
				        <td><input type="text" id="giconchange" name="giconchange" value="<?php echo esc_attr( get_option('giconchange') ); ?>" /></td>
				        </tr>
						<tr valign="top">
				        <th scope="row"><label for="gicontext_size">Gallery Icon Font-size</label> </th>
				        <td><input type="text" id="gicontext_size" name="gicontext_size" value="<?php echo esc_attr( get_option('gicontext_size') ); ?>" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="gicontext_color">Gallery Icon Color</label> </th>
				        <td><input type="text" id="gicontext_color" name="gicontext_color" value="<?php echo esc_attr( get_option('gicontext_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				         <tr valign="top">
				        <th scope="row"><label for="gicononoff">Gallery Icon On/Off Options</label></th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="gicononoff" type="checkbox" name="gicononoff" value="1" <?php checked(1, get_option('gicononoff'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>
			        </table>
			       
			        <table class="form-table">
			        	<h4>Testimonials Options Settings: </h4>
				        <tr valign="top">
				        <th scope="row"><label for="Ttitle_fontsize">Testimonials Title Font-size</label> </th>
				        <td><input type="text" id="Ttitle_fontsize" name="Ttitle_fontsize" value="<?php echo esc_attr( get_option('Ttitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Ttitle_color">Testimonials Title Color</label> </th>
				        <td><input type="text" id="Ttitle_color" name="Ttitle_color" value="<?php echo esc_attr( get_option('Ttitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Tttext_fontsize">Testimonials Title Text Font-size</label> </th>
				        <td><input type="text" id="Tttext_fontsize" name="Tttext_fontsize" value="<?php echo esc_attr( get_option('Tttext_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Tttext_color">Testimonials Title Text Color</label> </th>
				        <td><input type="text" id="Tttext_color" name="Tttext_color" value="<?php echo esc_attr( get_option('Tttext_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Ttext_fontsize">Testimonials Text Font-size</label> </th>
				        <td><input type="text" id="Ttext_fontsize" name="Ttext_fontsize" value="<?php echo esc_attr( get_option('Ttext_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Ttext_color">Testimonials Text Color</label> </th>
				        <td><input type="text" id="Ttext_color" name="Ttext_color" value="<?php echo esc_attr( get_option('Ttext_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Tatext_fontsize">Testimonials Author Name Font-size</label> </th>
				        <td><input type="text" id="Tatext_fontsize" name="Tatext_fontsize" value="<?php echo esc_attr( get_option('Tatext_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Tatext_color">Testimonials Author Name Color</label> </th>
				        <td><input type="text" id="Tatext_color" name="Tatext_color" value="<?php echo esc_attr( get_option('Tatext_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Tbulletonoff">Testimonials Bullet On/Off Options</label></th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="Tbulletonoff" type="checkbox" name="Tbulletonoff" value="1" <?php checked(1, get_option('Tbulletonoff'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>
			        </table>

			       
			        <table class="form-table">
			        	<h4>Upcomming Options Settings: </h4>

				        <tr valign="top">
				        <th scope="row"><label for="Etitle_fontsize">Upcomming Title Font-size</label> </th>
				        <td><input type="text" id="Etitle_fontsize" name="Etitle_fontsize" value="<?php echo esc_attr( get_option('Etitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Etitle_color">Upcomming Title Color</label> </th>
				        <td><input type="text" id="Etitle_color" name="Etitle_color" value="<?php echo esc_attr( get_option('Etitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Estitle_fontsize">Upcomming subtitle Font-size</label> </th>
				        <td><input type="text" id="Estitle_fontsize" name="Estitle_fontsize" value="<?php echo esc_attr( get_option('Estitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Estitle_color">Upcomming subtitle Color</label> </th>
				        <td><input type="text" id="Estitle_color" name="Estitle_color" value="<?php echo esc_attr( get_option('Estitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Etime_fontsize">Upcomming Time Font-size</label> </th>
				        <td><input type="text" id="Etime_fontsize" name="Etime_fontsize" value="<?php echo esc_attr( get_option('Etime_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Etime_color">Upcomming Time Color</label> </th>
				        <td><input type="text" id="Etime_color" name="Etime_color" value="<?php echo esc_attr( get_option('Etime_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Eaddress_fontsize">Upcomming Address Font-size</label> </th>
				        <td><input type="text" id="Eaddress_fontsize" name="Eaddress_fontsize" value="<?php echo esc_attr( get_option('Eaddress_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Eaddress_color">Upcomming Address Color</label> </th>
				        <td><input type="text" id="Eaddress_color" name="Eaddress_color" value="<?php echo esc_attr( get_option('Eaddress_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				         <tr valign="top">
				        <th scope="row"><label for="Etarikh_fontsize">Upcomming Date Font-size</label> </th>
				        <td><input type="text" id="Etarikh_fontsize" name="Etarikh_fontsize" value="<?php echo esc_attr( get_option('Etarikh_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Etarikh_color">Upcomming Date Color</label> </th>
				        <td><input type="text" id="Etarikh_color" name="Etarikh_color" value="<?php echo esc_attr( get_option('Etarikh_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				         <tr valign="top">
				        <th scope="row"><label for="Emonth_fontsize">Upcomming Month Font-size</label> </th>
				        <td><input type="text" id="Emonth_fontsize" name="Emonth_fontsize" value="<?php echo esc_attr( get_option('Emonth_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Emonth_color">Upcomming Month Color</label> </th>
				        <td><input type="text" id="Emonth_color" name="Emonth_color" value="<?php echo esc_attr( get_option('Emonth_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Eview_fontsize">Upcomming View Font-size</label> </th>
				        <td><input type="text" id="Eview_fontsize" name="Eview_fontsize" value="<?php echo esc_attr( get_option('Eview_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Eview_color">Upcomming View Color</label> </th>
				        <td><input type="text" id="Eview_color" name="Eview_color" value="<?php echo esc_attr( get_option('Eview_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				         <tr valign="top">
				        <th scope="row"><label for="Eviewback_color">Upcomming View Background Color</label> </th>
				        <td><input type="text" id="Eviewback_color" name="Eviewback_color" value="<?php echo esc_attr( get_option('Eviewback_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>
			    	 
			    <?php submit_button(); ?>

			</form>
			</div>
       
    </div>
     <div id="menu1" class="tab-pane fade">
     	<div class="wrap">
			<h1>Your Plugin Sermons Settings</h1>
				<form method="post" action="options.php">
				    <?php settings_fields( 'sermons_options_group' ); ?>
				    <?php do_settings_sections( 'Settings' ); ?>
				  <table class="form-table">
			        	<h4>Sermon Slider Options Settings: </h4>
				        <tr valign="top">
				        <th scope="row"><label for="slider_title">Slider Title Font-size</label> </th>
				        <td><input type="text" id="slider_title" name="title_fontsize" value="<?php echo esc_attr( get_option('title_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="slider_title">Slider Title Color</label> </th>
				        <td><input type="text" id="slider_title" name="title_color" value="<?php echo esc_attr( get_option('title_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="text_fontsize">Slider Text Font-size</label> </th>
				        <td><input type="text" id="text_fontsize" name="text_fontsize" value="<?php echo esc_attr( get_option('text_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="text_color">Slider Text Color</label> </th>
				        <td><input type="text" id="text_color" name="text_color" value="<?php echo esc_attr( get_option('text_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Readmore">Slider Readmore Font-size</label> </th>
				        <td><input type="text" id="text_fontsize" name="readmore_fontsize" value="<?php echo esc_attr( get_option('readmore_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="readmore_back">Readmore Background</label> </th>
				        <td><input type="text" id="readmore_back" name="readmore_background" value="<?php echo esc_attr( get_option('readmore_background') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="readmore_color">Readmore Color</label> </th>
				        <td><input type="text" id="readmore_color" name="readmore_color" value="<?php echo esc_attr( get_option('readmore_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="checkbox_bullet">Bullet On / Off Options</label> </th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="checkbox_bullet" type="checkbox" name="checkbox_bullet" value="1" <?php checked(1, get_option('checkbox_bullet'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="leftright_bullet">Left/Right Bullet On / Off Options</th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="leftright_bullet" type="checkbox" name="leftright_bullet" value="1" <?php checked(1, get_option('leftright_bullet'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>
			        </table>
				    
			          <table class="form-table">
			        	<h4>Leatest Sermons Settings: </h4>
				        <tr valign="top">
				        <th scope="row"><label for="Ltitle_fontsize">Leatest Title Font-size</label> </th>
				        <td><input type="text" id="Ltitle_fontsize" name="Ltitle_fontsize" value="<?php echo esc_attr( get_option('Ltitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Ltitle_color">Leatest Title Color</label> </th>
				        <td><input type="text" id="Ltitle_color" name="Ltitle_color" value="<?php echo esc_attr( get_option('Ltitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lstitle_fontsize">Leatest Sub Title Font-size</label> </th>
				        <td><input type="text" id="Lstitle_fontsize" name="Lstitle_fontsize" value="<?php echo esc_attr( get_option('Lstitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lstitle_color">Leatest Sub Title Color</label> </th>
				        <td><input type="text" id="Lstitle_color" name="Lstitle_color" value="<?php echo esc_attr( get_option('Lstitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lsctitle_fontsize">Leatest Content Title Font-size</label> </th>
				        <td><input type="text" id="Lsctitle_fontsize" name="Lsctitle_fontsize" value="<?php echo esc_attr( get_option('Lsctitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lsctitle_color">Leatest Content Title Color</label> </th>
				        <td><input type="text" id="Lsctitle_color" name="Lsctitle_color" value="<?php echo esc_attr( get_option('Lsctitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lscon_fontsize">Leatest Content Font-size</label> </th>
				        <td><input type="text" id="Lscon_fontsize" name="Lscon_fontsize" value="<?php echo esc_attr( get_option('Lscon_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lscon_color">Leatest Content Color</label> </th>
				        <td><input type="text" id="Lscon_color" name="Lscon_color" value="<?php echo esc_attr( get_option('Lscon_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Ltime_fontsize">Leatest Time Font-size</label> </th>
				        <td><input type="text" id="Ltime_fontsize" name="Ltime_fontsize" value="<?php echo esc_attr( get_option('Ltime_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Ltime_color">Leatest Time Color</label> </th>
				        <td><input type="text" id="Ltime_color" name="Ltime_color" value="<?php echo esc_attr( get_option('Ltime_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lread_fontsize">Leatest Read More Font-size</label> </th>
				        <td><input type="text" id="Lread_fontsize" name="Lread_fontsize" value="<?php echo esc_attr( get_option('Lread_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lread_color">Leatest Read More Color</label> </th>
				        <td><input type="text" id="Lread_color" name="Lread_color" value="<?php echo esc_attr( get_option('Lread_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lreadback_color">Leatest Read More Background Color</label> </th>
				        <td><input type="text" id="Lreadback_color" name="Lreadback_color" value="<?php echo esc_attr( get_option('Lreadback_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lreadborder_color">Leatest Read More border Color</label> </th>
				        <td><input type="text" id="Lreadborder_color" name="Lreadborder_color" value="<?php echo esc_attr( get_option('Lreadborder_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lsocial_fontsize">Leatest Social Font-size</label> </th>
				        <td><input type="text" id="Lsocial_fontsize" name="Lsocial_fontsize" value="<?php echo esc_attr( get_option('Lsocial_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lsocial_color">Leatest Social Color</label> </th>
				        <td><input type="text" id="Lsocial_color" name="Lsocial_color" value="<?php echo esc_attr( get_option('Lsocial_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lsocialback_color">Leatest Social Background Color</label> </th>
				        <td><input type="text" id="Lsocialback_color" name="Lsocialback_color" value="<?php echo esc_attr( get_option('Lsocialback_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lsocialborder_color">Leatest Social border Color</label> </th>
				        <td><input type="text" id="Lsocialborder_color" name="Lsocialborder_color" value="<?php echo esc_attr( get_option('Lsocialborder_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>

			         <table class="form-table">
			        	<h4>Sermons Staff Options Settings: </h4>
				        <tr valign="top">
				        <th scope="row"><label for="Lstaftitle_fontsize">Staff Title Font-size</label> </th>
				        <td><input type="text" id="Lstaftitle_fontsize" name="Lstaftitle_fontsize" value="<?php echo esc_attr( get_option('Lstaftitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lstaftitle_color">Staff Title Color</label> </th>
				        <td><input type="text" id="Lstaftitle_color" name="Lstaftitle_color" value="<?php echo esc_attr( get_option('Lstaftitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
				        <tr valign="top">
				        <th scope="row"><label for="Lstafstitle_fontsize">Staff Sub Title Font-size</label> </th>
				        <td><input type="text" id="Lstafstitle_fontsize" name="Lstafstitle_fontsize" value="<?php echo esc_attr( get_option('Lstafstitle_fontsize') ); ?>" /></td>
				        </tr>

				        <tr valign="top">
				        <th scope="row"><label for="Lstafstitle_color">Staff Sub Title Color</label> </th>
				        <td><input type="text" id="Lstafstitle_color" name="Lstafstitle_color" value="<?php echo esc_attr( get_option('Lstafstitle_color') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>

				    <?php submit_button(); ?>

				</form>
			
			</div>
    </div>
    <div id="menu2" class="tab-pane fade">
     	<div class="wrap">
			<h1>Your Plugin Pages Settings</h1>
				<form method="post" action="options.php">
				    <?php settings_fields( 'pages_options_group' ); ?>
				    <?php do_settings_sections( 'Settings' ); ?>
				  <table class="form-table">
			        	<h4>Sermons Page Settings: </h4>
				        <tr valign="top">
				        <th scope="row">Body font-size</th>
				        <td><input type="text" name="input_field" value="<?php echo esc_attr( get_option('input_field') ); ?>" /></td>
				        </tr>

				         <tr valign="top">
				        <th scope="row">On / Off Options</th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="checkbox" type="checkbox" name="checkbox" value="1" <?php checked(1, get_option('checkbox'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>

				        <tr valign="top">
				        <th scope="row">Some Other Option</th>
				        <td> <input type="text" name="color_picker" value="<?php echo esc_attr( get_option('color_picker') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>
			         <table class="form-table">
			        	<h4>Sermon Single Page Settings: </h4>
				        <tr valign="top">
				        <th scope="row">Body font-size</th>
				        <td><input type="text" name="input_field" value="<?php echo esc_attr( get_option('input_field') ); ?>" /></td>
				        </tr>

				         <tr valign="top">
				        <th scope="row">On / Off Options</th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="checkbox" type="checkbox" name="checkbox" value="1" <?php checked(1, get_option('checkbox'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>

				        <tr valign="top">
				        <th scope="row">Some Other Option</th>
				        <td> <input type="text" name="color_picker" value="<?php echo esc_attr( get_option('color_picker') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>
			         <table class="form-table">
			        	<h4>Events Single Page Settings: </h4>
				        <tr valign="top">
				        <th scope="row">Body font-size</th>
				        <td><input type="text" name="input_field" value="<?php echo esc_attr( get_option('input_field') ); ?>" /></td>
				        </tr>

				         <tr valign="top">
				        <th scope="row">On / Off Options</th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="checkbox" type="checkbox" name="checkbox" value="1" <?php checked(1, get_option('checkbox'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>

				        <tr valign="top">
				        <th scope="row">Some Other Option</th>
				        <td> <input type="text" name="color_picker" value="<?php echo esc_attr( get_option('color_picker') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>
			         <table class="form-table">
			        	<h4>Author Page Settings: </h4>
				        <tr valign="top">
				        <th scope="row">Body font-size</th>
				        <td><input type="text" name="input_field" value="<?php echo esc_attr( get_option('input_field') ); ?>" /></td>
				        </tr>

				         <tr valign="top">
				        <th scope="row">On / Off Options</th>
				        <td><div class="onoffbtn"> 
		                   		<div class="switch">
									<input id="checkbox" type="checkbox" name="checkbox" value="1" <?php checked(1, get_option('checkbox'), true); ?> />
									<label><i></i></label>
								</div> 
		                   </div>
				        </td>
				        </tr>

				        <tr valign="top">
				        <th scope="row">Some Other Option</th>
				        <td> <input type="text" name="color_picker" value="<?php echo esc_attr( get_option('color_picker') ); ?>" class="my-color-field" data-default-color="#effeff" /></td>
				        </tr>
			        </table>
				    
				    <?php submit_button(); ?>

				</form>
			
			</div>
    </div>

    <div id="menu3" class="tab-pane fade">
      <div class="wrap">
		<h1>Your Plugin Name</h1>
		<form method="post" action="options.php">
			    <?php settings_fields( 'banner_options_group' ); ?>
			    <?php do_settings_sections( 'Settings' ); ?>
			    	<table class="form-table">
			        <tr valign="top">
			        <th scope="row"><label for="getimg">Sermons Page Banner</label></th>
			        <td> <button type="button" required id="btnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="banner_img" class="getimg" id="getbanner_input" 
			        	 value="<?php echo esc_attr( get_option('banner_img') ); ?>" /><img src="<?php echo get_option('banner_img'); ?>" id="getbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>

			         <tr valign="top">
			        <th scope="row"><label for="sgetimg">Sermons Single Banner</label></th>
			        <td> <button type="button" required id="sbtnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="sbanner_img" class="sgetimg" id="sgetbanner_input" 
			        	 value="<?php echo esc_attr( get_option('sbanner_img') ); ?>" /><img src="<?php echo get_option('sbanner_img'); ?>" id="sgetbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>
			         <tr valign="top">
			        <th scope="row"><label for="egetimg">Events Single Banner</label></th>
			        <td> <button type="button" required id="ebtnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="ebanner_img" class="egetimg" id="egetbanner_input" 
			        	 value="<?php echo esc_attr( get_option('ebanner_img') ); ?>" /><img src="<?php echo get_option('ebanner_img'); ?>" id="egetbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>
			       
			        <tr valign="top">
			        <th scope="row"><label for="agetimg">Author Page Banner</label></th>
			        <td> <button type="button" required id="abtnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="abanner_img" class="agetimg" id="agetbanner_input" 
			        	 value="<?php echo esc_attr( get_option('abanner_img') ); ?>" /><img src="<?php echo get_option('abanner_img'); ?>" id="agetbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>
			        <tr valign="top">
			        <th scope="row"><label for="agetimg">Latest Sermon Banner Or Background Color</label></th>
			        <td> <button type="button" required id="abtnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="abanner_img" class="agetimg" id="agetbanner_input" 
			        	 value="<?php echo esc_attr( get_option('abanner_img') ); ?>" /><img src="<?php echo get_option('abanner_img'); ?>" id="agetbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>
			         <tr valign="top">
			        <th scope="row"><label for="agetimg">Testimonials Banner Or Background Color</label></th>
			        <td> <button type="button" required id="abtnbanner">Upload Image</button><br/>
			        	<input type="hidden" name="abanner_img" class="agetimg" id="agetbanner_input" 
			        	 value="<?php echo esc_attr( get_option('abanner_img') ); ?>" /><img src="<?php echo get_option('abanner_img'); ?>" id="agetbanner_id" height="100px" width="400px"/>
			        </td>
			        </tr>
			    </table>
			    <?php submit_button(); ?>
			</form>
		
		</div>
    </div>
  </div>
</div>

