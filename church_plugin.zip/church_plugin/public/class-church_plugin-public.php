<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    church_plugin
 * @subpackage church_plugin/public
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( "bootstrap", plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "dataTables", plugin_dir_url( __FILE__ ) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "notifyBar", plugin_dir_url( __FILE__ ) . 'css/jquery.notifyBar.css', array(), $this->version, 'all' );
		wp_enqueue_style( "church_plugin", plugin_dir_url( __FILE__ ) . 'css/church_plugin-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( "church_plugin", plugin_dir_url( __FILE__ ) . 'css/owl.carousel.css', array(), $this->version, 'all' );
		wp_enqueue_style( "church_plugin", plugin_dir_url( __FILE__ ) . 'css/owl.theme.css', array(), $this->version, 'all' );
		wp_enqueue_style( "font-awesome", plugin_dir_url( __FILE__ ) . 'css/font-awesome.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "baguetteBox", plugin_dir_url( __FILE__ ) . 'css/baguetteBox.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "fluid-gallery", plugin_dir_url( __FILE__ ) . 'css/fluid-gallery.css', array(), $this->version, 'all' );
		wp_enqueue_style( "owl.carousel.min", plugin_dir_url( __FILE__ ) . 'css/owl.carousel.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "owl.theme.default", plugin_dir_url( __FILE__ ) . 'css/owl.theme.default.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( "bootstrap", plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "dataTables", plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "jquery", plugin_dir_url( __FILE__ ) . 'js/jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "notifyBar", plugin_dir_url( __FILE__ ) . 'js/jquery.notifyBar.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "validate", plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "church_plugin", plugin_dir_url( __FILE__ ) . 'js/church_plugin-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "owl.carousel", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "carousel", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.min.js', array( 'jquery' ), $this->version, false );
        wp_enqueue_script( "baguetteBox", plugin_dir_url( __FILE__ ) . 'js/baguetteBox.min.js', array( 'jquery' ), $this->version, false );
        wp_enqueue_script( "carousel", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "owl.carousel.min", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.min.js', array( 'jquery' ), $this->version, false );
	}


    //--------------------single sermon page
	public function font_page_method_for_single($template) {
	    global $post;
		    if ($post->post_type == "sermon" && $template !== locate_template(array("single-sermon.php"))){
		        $page_template11 = churchPLUGIN_URL. "/public/partials/font-pages/single-sermon.php";
		        return $page_template11;
		    }
		    return $template;
	}
   //--------------------events single page
	public function font_page_method_for_single_events($template) {
	    global $post;
		    if ($post->post_type == "events" && $template !== locate_template(array("single-events.php"))){
		        $page_template11 = churchPLUGIN_URL. "/public/partials/font-pages/single-events.php";
		        return $page_template11;
		    }
		    return $template;
	}
	//-------------------- sermon author page
	public function font_page_method_for_author( $template ) {
	    $file = '';
	    if ( is_author() ) {
	        $file   = 'sermon-author.php'; // the name of your custom template
	        $find[] = $file;
	        $find[] = 'church_plugin/' . $file; // name of folder it could be in, in user's theme
	    } 
	    if ( $file ) {
	        $template  = locate_template( array_unique( $find ) );
	        if ( ! $template ) { 
	            $template = churchPLUGIN_URL. "public/partials/font-pages/sermon-author.php";
	        }
	    }
	    return $template;
	}

	//-------------------- sermon page
	public function font_page_method_for_sermonspage($page_template1){
  		global $post;
  		$post_slug = $post->post_name;
  		if($post_slug == "sermons-page"){
  			$page_template1 = churchPLUGIN_URL. "/public/partials/font-pages/church_font-end_page.php";
  		}
  		return $page_template1;
	}



	//-------------------- shortcode registation all
	public function register_shortcodes() {
	  //custom all shortcode	
	  add_shortcode("Slider",array($this, "slider_font_end_pagsde"));
	  add_shortcode("testimonilas",array($this, "testimonilas_shortcode_method"));
	  add_shortcode("Gallery",array($this, "Gallery_font_end_pags"));
	  add_shortcode("Events",array($this, "Events_font_end_pags"));
	  add_shortcode("Sermons",array($this, "Sermons_font_end_pags"));
	  add_shortcode("Staff",array($this, "Staff_font_end_pags"));
	}


	//-------------------- shortcode call page
	 public function slider_font_end_pagsde(){
	 	include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_page.php";
	 }

	public function testimonilas_shortcode_method(){
	   include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_testimonials.php";
	}

	public function Gallery_font_end_pags(){
		include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_galley.php";
	}
	public function Events_font_end_pags(){
		include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_events.php";
	}

	public function Sermons_font_end_pags(){
		include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_sermons.php";
	}

	public function Staff_font_end_pags(){
		include_once churchPLUGIN_URL. "/public/partials/font-pages/church_font_call_staff.php";
	}
    

}

?>