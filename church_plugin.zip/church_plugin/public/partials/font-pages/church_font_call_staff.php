
<?php 

$Lstaftitle_fontsize = get_option('Lstaftitle_fontsize');
$Lstaftitle_color = get_option('Lstaftitle_color');
$Lstafstitle_fontsize = get_option('Lstafstitle_fontsize');
$Lstafstitle_color = get_option('Lstafstitle_color');


?>

<style type="text/css"> 
  
</style>
<!-- Stylesheets -->
    <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,400italic,300italic' rel='stylesheet' type='text/css'>
<div class="Staff_area">
   <div class="container">
       <div class="Staff_header">
          <h2 style="font-size: <?php echo $Lstaftitle_fontsize;?>; color: <?php echo $Lstaftitle_color;?>">OUR STAFF</h2>
          <h4 style="font-size: <?php echo $Lstafstitle_fontsize;?>; color: <?php echo $Lstafstitle_color;?>">The churches must learn humility as well as teach it</h4>
       </div>
       
          <div class="owl-carousel owl-theme">
            <?php $catquery = new WP_Query(array(
                'post_type' => 'Staff',
                'posts_per_page' => 4
              )); ?>
          
                 <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                   <div class="item">
                       <div class="single_slide_item Staff">
                        <div class="images img_change">
                           <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                        </div>
                        <h4><?php echo get_the_title(); ?></h4>
                        <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?>
                        </p>
                        <ul class="Staff_socila">
                          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                          <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        </ul>
                    </div>
                    </div>
                  <?php endwhile; ?> 
                <?php wp_reset_postdata(); ?>
          </div>

   </div>     
</div>
