<div id="carousel-example-generic" class="carousel slide carousel-fade"   data-ride="carousel">
            <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <!-- Indicators -->
            <?php $leftright = (get_option('checkbox_bullet'));
             if($leftright == 1){
              echo '<ol class="carousel-indicators">
              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-generic" data-slide-to="1"></li>
              <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>';
             }else{
              echo '<ol style="display:none;" class="carousel-indicators">
            </ol>';
             }?>
            
             <!-- for carousel all item show -->
             <?php 
              $ektaveriable = new WP_Query(array(
                'post_type' => 'custom_post_type',
                'posts_per_page' => 3
              ));
              ?>
              <?php $veriable2 = 0; while($ektaveriable->have_posts()) : $ektaveriable->the_post(); $veriable2++ ?>
                              
              <?php if($veriable2 == 1) : ?>
               <div class="item active">
              <?php else : ?>
               <div class="item">
              <?php endif; ?>
              <div class="single_slide_item ">
                 <div class="slider_text">
                     <?php 
                        $title_fontsize = (get_option('title_fontsize')); 
                        $title_color = (get_option('title_color'));
                        $text_fontsize = (get_option('text_fontsize'));
                        $text_color = (get_option('text_color'));
                        $readmore_fontsize = (get_option('readmore_fontsize'));
                        $readmore_background = (get_option('readmore_background'));
                        $readmore_color = (get_option('readmore_color'));
                     ?>
                    <h2 style="font-size:<?php echo $title_fontsize;?>; color:<?php echo $title_color;?>"><?php echo get_the_title(); ?></h2>
                    <p style="font-size:<?php echo $text_fontsize;?>; color:<?php echo $text_color;?>">
                      <?php echo get_the_content(); ?></p>
                    <a style="font-size:<?php echo $readmore_fontsize;?>; color:<?php echo $readmore_color;?>; background: <?php echo $readmore_background;?>" href="<?php echo get_post_meta(get_the_ID(),'sliderreadmoreurl', true); ?>"> <?php echo get_post_meta(get_the_ID(),'readmore', true); ?></a>
                  </div>
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
              </div>
              </div>
              <?php endwhile;?>
           
          </div>
         <!-- Controls -->
         <?php $leftright = (get_option('leftright_bullet'));
          if($leftright == 1){
            echo '<div class="leftright">
            <a class="left changeicon" href="#carousel-example-generic" role="button" data-slide="prev">
            <i class="fa fa-angle-left"></i>
            </a>
            <a class="right changeicon" href="#carousel-example-generic" role="button" data-slide="next">
             <i class="fa fa-angle-right"></i>
            </a>
         </div>  ';
          }
          else{
            echo '<div style="display:none;" class="leftright">
         </div>  ';
          }

          ?>
       
      </div>
      
