<?php 

 get_header(); // header php
	echo do_shortcode("[slider_shortcode_test]");
	echo do_shortcode("[slider_shortcode_test1]");
	echo do_shortcode("[slider_shortcode_test2]");
   
 get_footer();// footer php
?>


	