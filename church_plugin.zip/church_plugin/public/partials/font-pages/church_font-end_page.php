<?php 

/*
Template Name: Sermons Page
*/

get_header(); 


?>
<?php 
	ob_start();
	include_once churchPLUGIN_URL."/public/partials/font-pages/modal.php";
	$template = ob_get_contents();
	ob_end_clean();
	echo $template;
?>

<section class="sermons_area_top_banner" style="background: url(<?php echo get_option('banner_img'); ?>); background-size: cover;">
   <div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_blog">
	     			<h4>Sermons Blog Page</h4>
					<?php if(have_posts()):while(have_posts()):the_post(); ?>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								  <div class="menu_left">
									   <h2><?php the_title(); ?></h2>
								  </div>
							</div>
					   <?php endwhile; endif; ?>
			    </div>
            </div>		
        </div>
    </div>
 </section> 	
<section class="sermons_area">
	<div class="container">
		<div class="row">
		
		    <div class="col-md-12">
	     		<div class="sermons_header_main">
				    <?php 
				          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				          $args = array(
				              'post_type'=>'sermon', // Your post type name
				              'posts_per_page' => 6,
				              'paged' => $paged,
				          );

				          $loop = new WP_Query( $args );
				          if ( $loop->have_posts() ) {
				              while ( $loop->have_posts() ) : $loop->the_post();
				             ?>
				            <div class="col-md-4">
				              <div class="Sermons_twopart sermons">
				              	  <div class="sermons_img">
				              	  	<a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
				              	  </div>
				              	  <div class="sermons_text">
				              	  	<h4><?php echo get_the_title(); ?></h4>
				              	  	<p class="author partor">
				              	  	 	<span class="pastor blog"><?php echo get_post_meta(get_the_ID(),'author_aaa', true); ?> : </span> 

				              	  	 	<span class="auth blog"><a href="<?php echo get_author_posts_url($current_user->ID); ?>"><?php echo get_the_author(); ?></a> </span>
				              	  	</p>

				              	  	<p class="content"><?php $content =  get_the_content(); $abc = substr($content, 0, 90);
	    								 	echo $abc; ?><a href="<?php echo get_the_permalink(); ?>"> Read More</a>
	    							 </p>
				              	  </div>
				                  <ul class="social_icon"> 
				                      <li><button type="button" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
				                      <li><button type="button" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
				                      <li><a href="<?php echo get_post_meta($post->ID,'readmoreurl', true); ?>"><i class="fa fa-book"></i></a></li>
				                      <li><a href="<?php echo get_post_meta($post->ID,'readmoreurl', true); ?>"><i class="fa fa-download"></i></a></li>
				                  </ul>
				              </div>
				           </div>
				            <?php 
				              endwhile;
				              ?><div class="col-sm-12 col-md-12">
				              	  <div class="paginatione"><?php 
						              $total_pages = $loop->max_num_pages;
						              if ($total_pages > 1){
						                 $current_page = max(1, get_query_var('paged'));
						                  echo paginate_links(array(
						                      'base' => get_pagenum_link(1) . '%_%',
						                      'format' => '/page/%#%',
						                      'current' => $current_page,
						                      'total' => $total_pages,
						                      'prev_text'    => __('« prev'),
						                      'next_text'    => __('next »'),
						                  ));
						              }
				                     ?></div></div>
				                 <?php }
				            wp_reset_postdata();
				        ?>
				</div>
         	</div>		
      </div>
    </div>
 </section> 




<?php echo do_shortcode( '[Slider]' ); ?>
<?php echo do_shortcode( '[testimonilas]' ); ?>
<?php echo do_shortcode( '[Gallery]' ); ?>
<?php echo do_shortcode( '[Events]' ); ?>
<?php echo do_shortcode( '[Sermons]' ); ?>
<?php echo do_shortcode( '[Staff]' ); ?>




<?php
get_footer();


?>
