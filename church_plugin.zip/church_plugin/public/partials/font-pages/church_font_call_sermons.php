
 <?php 
  ob_start();
  include_once churchPLUGIN_URL."/public/partials/font-pages/modal.php";
  $template = ob_get_contents();
  ob_end_clean();
  echo $template;
?>
<?php 

$Ltitle_fontsize = get_option('Ltitle_fontsize');
$Ltitle_color = get_option('Ltitle_color');
$Lstitle_fontsize = get_option('Lstitle_fontsize');
$Lstitle_color = get_option('Lstitle_color');

$Lsctitle_fontsize = get_option('Lsctitle_fontsize');
$Lsctitle_color = get_option('Lsctitle_color');
$Lscon_fontsize = get_option('Lscon_fontsize');
$Lscon_color = get_option('Lscon_color');
$Ltime_fontsize = get_option('Ltime_fontsize');
$Ltime_color = get_option('Ltime_color');

$Lread_fontsize = get_option('Lread_fontsize');
$Lread_color = get_option('Lread_color');
$Lreadback_color = get_option('Lreadback_color');
$Lreadborder_color = get_option('Lreadborder_color');

$Lsocial_fontsize = get_option('Lsocial_fontsize');
$Lsocial_color = get_option('Lsocial_color');
$Lsocialback_color = get_option('Lsocialback_color');
$Lsocialborder_color = get_option('Lsocialborder_color');
?>

<style type="text/css"> 
   .Sermons_twopart_title h4 {
	font-size: <?php echo $Lsctitle_fontsize;?>;
	color: <?php echo $Lsctitle_color;?>;
}
.content {
	font-size: <?php echo $Lscon_fontsize;?>;
	color: <?php echo $Lscon_color;?>;
}
.Ltime {
	font-size: <?php echo $Ltime_fontsize;?>;
	color: <?php echo $Ltime_color;?>;
}
.View_button.sermons a {
	background: <?php echo $Lreadback_color;?>;
	color: <?php echo $Lread_color;?>;
	font-size: <?php echo $Lread_fontsize;?>;
	border: 1px solid <?php echo $Lreadborder_color;?>;
	padding: 8px 20px;
}
/*.social_icon li button {
	color: <?php  $Lsocial_color;?>;
	border: 1px solid <?php  $Lsocialborder_color;?>;
	font-size: <?php  $Lsocial_fontsize;?>;
	background: <?php  $Lsocialback_color;?>;
}
.social_icon li a {
	color: <?php  $Lsocial_color;?>;
	border: 1px solid <?php  $Lsocialborder_color;?>;
	font-size: <?php  $Lsocial_fontsize;?>;
	background: <?php  $Lsocialback_color;?>;
}*/
</style>

<div class="upcomming_sermons_area"> 
  <div class="container">
   <div class="sermons_header">
      <h2 style="font-size: <?php echo $Ltitle_fontsize;?>; color: <?php echo $Ltitle_color;?>">LATEST SERMON</h2>
      <h4 style="font-size: <?php echo $Lstitle_fontsize;?>; color: <?php echo $Lstitle_color;?>">Experience God's Presence</h4>
   </div>
    <?php $catquery = new WP_Query(array(
		'post_type' => 'sermon',
		'posts_per_page' => 3
	  )); ?>

		 <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
		    <div class="row add bg">
				<div class="col-md-2">
				  <div class="Sermons_twopart_img">
					  <div class="Sermons_images changesss">
					  <a href="<?php echo get_page_link( get_page_by_path( 'sermons_blog' ) ); ?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
					  </div>
				  </div>
				 </div>
				<div class="col-md-7 some">
				<div class="Sermons_twopart_title">
					<h4><?php echo get_the_title(); ?></h4>
					<p class="content"><?php $content = get_the_content(); $abc = substr($content, 0, 150); echo $abc; ?></p>
					 <p class="Ltime"><?php the_time('l, F jS, Y') ?></p>
				</div>
			   </div>
				<div class="col-md-3">
				  <div class="Sermons_twopart">
					  <ul class="social_icon"> 
						  <li><button type="button" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
						  <li><button type="button" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
						  <li><a href="<?php echo get_post_meta(get_the_ID(),'readmoreurl', true); ?>"><i class="fa fa-book"></i></a></li>
					  </ul>
					  <div class="View_button sermons">
						   <a href="<?php echo get_page_link( get_page_by_path( 'sermons_blog' ) ); ?>">View Now</a>
					  </div>
				  </div>
			   </div>
			</div>
		  <?php endwhile; ?> 
		<?php wp_reset_postdata(); ?>

  </div>
</div>


