(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	 $(function(){
	     window.addEventListener("load", setListeners());
  
  String.prototype.endsWith = function(suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
  };
  var audio = new Audio();
  function setListeners(){
    var index = 0;
    var buttons = document.getElementsByClassName("soundBt");
    for (index = 0; index < buttons.length; index++){
      var button = buttons[index];
      button.addEventListener("click", function(){
        var buttons = document.getElementsByClassName("soundBt");
        var index = 0;
        for (index = 0; index < buttons.length; index++){
          buttons[index].style.background = "#ff533d";
          
        }
        if(audio.paused){
          var fileToPlay = this.getAttribute("name");
          audio.src = fileToPlay;
          audio.play();
          this.style.background = "url(https://cdn3.iconfinder.com/data/icons/website-1/128/button1-128.png) no-repeat";
          
        } 
        else{ 

          audio.pause();
          this.style.background = "url(https://cdn4.iconfinder.com/data/icons/video-3/128/Video_play-05-128.png) no-repeat";
        
        }
      });
    }
  }
  audio.addEventListener("ended", function(){
    var buttons = document.getElementsByClassName("soundBt");
    var index = 0;
    for (index = 0; index < buttons.length; index++){
      var button = buttons[index];
      var buttonName = button.getAttribute("name");
      var audiosrc = audio.src;
      if (audio.src.endsWith(buttonName)){
        button.style.background = "url(assets/file/audio/play.png) no-repeat";
        return;
      }
    }
  });
  
	});

  $(document).ready(function() {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
      margin: 10,
      nav: true,
      loop: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 3
        },
        1000: {
          items: 5
        }
      }
    })
  })
})( jQuery );
